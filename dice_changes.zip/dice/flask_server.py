# from flask import Flask, request, jsonify
# from flask_cors import CORS  # Import CORS
# import sys
# import rospy
# from std_msgs.msg import String
# from qt_robot_interface.srv import *
# from qt_gesture_controller.srv import *

# app = Flask(__name__)
# CORS(app)  # Enable CORS for all routes

# # Create publishers
# speechSay_pub = rospy.Publisher('/qt_robot/speech/say', String, queue_size=10)
# audioPlay_pub = rospy.Publisher('/qt_robot/audio/play', String, queue_size=10)
# emotionShow_pub = rospy.Publisher('/qt_robot/emotion/show', String, queue_size=10)
# gesturePlay_pub = rospy.Publisher('/qt_robot/gesture/play', String, queue_size=10)
# behaviorTalkText_pub = rospy.Publisher('/qt_robot/behavior/talkText', String, queue_size=10)
# behaviorTalkAudio_pub = rospy.Publisher('/qt_robot/behavior/talkAudio', String, queue_size=10)

# # Create service proxies
# audioPlay = rospy.ServiceProxy('/qt_robot/audio/play', audio_play)
# speechSay = rospy.ServiceProxy('/qt_robot/speech/say', speech_say)
# gesturePlay = rospy.ServiceProxy('/qt_robot/gesture/play', gesture_play)
# emotionShow = rospy.ServiceProxy('/qt_robot/emotion/show', emotion_show)
# behaviorTalkText = rospy.ServiceProxy('/qt_robot/behavior/talkText', behavior_talk_text)
# behaviorTalkAudio = rospy.ServiceProxy('/qt_robot/behavior/talkAudio', behavior_talk_audio)

# # Wait for connections
# wtime_begin = rospy.get_time()
# while (speechSay_pub.get_num_connections() == 0 or
#        audioPlay_pub.get_num_connections() == 0 or
#        emotionShow_pub.get_num_connections() == 0 or
#        gesturePlay_pub.get_num_connections() == 0 or
#        behaviorTalkText_pub.get_num_connections() == 0 or
#        behaviorTalkAudio_pub.get_num_connections() == 0 ) :
#     rospy.loginfo("waiting for subscriber connections")
#     if rospy.get_time() - wtime_begin > 5.0:
#         rospy.logerr("Timeout while waiting for subscribers connection!")
#         sys.exit()
#     rospy.sleep(1)

# @app.route('/activity', methods=['GET', 'POST'])
# def activity():
#     if request.method == 'POST':
#         data = request.json
#         activity = data['activity']
#         print(f"Received activity: {activity}")

#         # Call the appropriate action based on the activity
#         if activity == "Hug":
#             hug_action()
#         elif activity == "Clap":
#             clap_action()
#         elif activity == "Swim":
#             swim_action()
#         elif activity == "Jump":
#             jump_action()
#         elif activity == "Run":
#             run_action()
#         elif activity == "Shower":
#             shower_action()

#         return jsonify({"status": "success", "activity": activity})
#     else:
#         return "Send a POST request to this endpoint.", 200

# def hug_action():
#     speechSay_pub.publish("I am giving a hug!")  # Robot says the action
#     # Add any other actions related to hugging, e.g., a gesture

# def clap_action():
#     speechSay_pub.publish("I am clapping!")  # Robot says the action
#     # Add any other actions related to clapping, e.g., a gesture

# def swim_action():
#     speechSay_pub.publish("I am swimming!")  # Robot says the action
#     # Add any other actions related to swimming, e.g., a gesture

# def jump_action():
#     speechSay_pub.publish("I am jumping!")  # Robot says the action
#     # Add any other actions related to jumping, e.g., a gesture

# def run_action():
#     speechSay_pub.publish("I am running!")  # Robot says the action
#     # Add any other actions related to running, e.g., a gesture

# def shower_action():
#     speechSay_pub.publish("I am taking a shower!")  # Robot says the action
#     # Add any other actions related to showering, e.g., a gesture

# if __name__ == '__main__':
#     rospy.init_node('python_qt_example')  # Initialize the ROS node
#     rospy.loginfo("ready...")
#     app.run(host='0.0.0.0', port=5000)



from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/activity', methods=['GET', 'POST'])
def activity():
    if request.method == 'POST':
        data = request.json
        activity = data['activity']
        print(f"Received activity: {activity}")
        
        # Add logic to control the QT robot based on the activity
        if activity == "shower":
            wave_hello()  # Example action for QT robot
        elif activity == "exercise":
            exercise_action()

        return jsonify({"status": "success", "activity": activity})
    else:
        return "Send a POST request to this endpoint.", 200


def wave_hello():
    print("QT robot is waving hello!")

def exercise_action():
    print("QT robot is starting exercise mode!")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)